package main;

import java.util.Scanner;

import datos.Documentos;

public class App {
    static Documentos miDocumento = new Documentos();
    public static void main(String[] args) {
        String linea = "*";
        Scanner sc =  new Scanner(System.in);

        System.out.println("Escribe lineas (fin para terminar):");
        do {
            linea = sc.nextLine();
            miDocumento.nuevaLinea(linea);
        } while (!linea.equals("fin"));
        miDocumento.guardar();
        //System.out.println(miDocumento.getMiArrayList().toString());
    }        
}
