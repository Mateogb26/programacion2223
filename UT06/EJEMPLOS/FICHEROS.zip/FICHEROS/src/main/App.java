package main;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import archivos.Archivos;

/* CODIGO EXTRAIDO DE 
https://www.w3schools.com/java/java_files.asp
*/

public class App {
    public static void main(String[] args) {
        Archivos miArchivo = new Archivos();
        miArchivo.lee();
    }

    
    

}
