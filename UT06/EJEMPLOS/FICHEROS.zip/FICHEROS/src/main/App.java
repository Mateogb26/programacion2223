package main;

import java.util.ArrayList;
import java.util.Scanner;

import datos.Documentos;

/**
 * Clase principal que muestra los datos por pantalla
 *
 * @author Joaquin Rios
 * @version 2023.02.28
 */
public class App {
    static Documentos miDocumento = new Documentos();
    static Menu miMenu;
    /**
     * Aplicacion principal
     * @param args argumentos de la app
     */
    public static void main(String[] args) {
        int opcion=99;
        crearMenu();

        do {
            miMenu.verMenu();
            opcion = miMenu.leerOpcion();
            switch (opcion) {
                case 1: 
                    escribir();
                break;
                case 2: 
                    verDocumento();
                break;
                case 3:
                    
                break;

            }
        } while (opcion!=0);
        
    }       
    
    /**
     * Añade lineas al documento
     */
    public static void escribir() {
        String linea = "";
        Scanner sc = new Scanner(System.in);

        System.out.println("Escribe lineas (fin para terminar):");
        do {
            linea = sc.nextLine();
            if (!linea.equals("fin")) {
                miDocumento.nuevaLinea(linea);
            }
        } while (!linea.equals("fin"));
        miDocumento.guardar();
    }

    /**
     * Muestra por pantalla el documento actual
     */
    public static void verDocumento() {
        // Me copio el documento en mi ArrayList
        // para recorrer las lineas 
        var miDoc = miDocumento.getMiArrayList();
        // recorro la copia y muestro el 
        // numero de linea y el contenido
        for (int i=0; i<miDoc.size(); i++) {
            System.out.print(i+1 + ": "+miDoc.get(i));
        }
    }

    /**
     * crea el menu con mis opciones
     */
    public static  void crearMenu() {
        ArrayList<String> listaOpciones = new ArrayList<>();
        listaOpciones.add("AÑADIR LINEAS");
        listaOpciones.add("VER DOCUMENTO");
        listaOpciones.add("REESCRIBIR DOCUMENTO (RESET)");
        miMenu = new Menu(listaOpciones, "DOCUMENTOS");

    }
}
