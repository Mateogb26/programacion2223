package es.ieslosalbares;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

@SpringBootApplication
public class Main {
    public static void main(String[] args) {
        SpringApplication.run(Main.class);
    }

    @Bean
    public CommandLineRunner demo(PersonaRepositorio repositorio) {
        return (args) -> {
            System.out.println("pepe");
            Persona pepe = new Persona("pepe");

            repositorio.findById(1L);
        };
    }


}