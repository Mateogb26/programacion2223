package es.ieslosalbares.agenda.modelo;

import org.springframework.data.repository.CrudRepository;

public interface PersonaRepositorio extends CrudRepository<Persona , Long> {
}
