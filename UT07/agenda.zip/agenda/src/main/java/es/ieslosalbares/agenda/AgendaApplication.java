package es.ieslosalbares.agenda;

import es.ieslosalbares.agenda.modelo.Persona;
import es.ieslosalbares.agenda.modelo.PersonaRepositorio;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class AgendaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgendaApplication.class, args);
	}

	@Bean
	public CommandLineRunner prueba(PersonaRepositorio agenda) {
		return (args) -> {
			Persona pepe = new Persona("Antonio");
			agenda.save(pepe);
		};
	}

}
