/* 
* EJEMPLO01-App.java
* Autor: Joaquin Rios
* Aplicacion que simula la clase y el objeto coche
*/
package EJEMPLO01;

import java.util.Scanner;

public class App {
    /**
     * @param args
     */
    public static void main(String[] args) {
        int opcion=10;
        Scanner entrada = new Scanner(System.in);

        coche miToyota = new coche();

        
        
        while (opcion!=0) {
            System.out.println("¿Que quieres hacer hoy?");
            System.out.println("1. CONDUCIR");
            System.out.println("2. ECHAR GASOLINA");
            System.out.println("0. SALIR");
            System.out.print("ESCRIBE TU OPCIÓN: ");
            opcion = entrada.nextInt();
            if (opcion == 1) {
                 System.out.println("¿CUANTOS KILOMETROS?");
                 int kilometros = entrada.nextInt();
                 miToyota.conducir(kilometros);   
            }

            if (opcion == 2) {
                System.out.println("¿CUANTOS LITROS?");
                int litros = entrada.nextInt();
                miToyota.repostar(litros);
            }

            if (opcion == 3) {
                
            }

            if (opcion == 0) {
                System.out.println("SAYONARA, BABY");
            }
        }

        
    }
}
