import java.util.ArrayList;
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {               
        int opcion;
        Pedidos pedidoUno = new Pedidos(1);
        Menu miMenu;
        ArrayList<String>  listaOpciones = new ArrayList<>();

        listaOpciones.add("AGREGAR PRODUCTO");
        listaOpciones.add("ELIMINAR ULTIMO PRODUCTO");
        listaOpciones.add("ELIMINAR TODOS LOS PRODUCTOS");
        
        miMenu = new Menu(listaOpciones);

        

        while (true) {
            miMenu.verMenu();
            opcion = miMenu.leerOpcion();
            if (opcion == 1) {
                pedidoUno.agregarProducto();
                System.out.println("PRODUCTO AÑADIDO. LA" 
                + " LISTA DE PRODUCTOS ES LA SIGUIENTE");
                pedidoUno.verListaProductos();
            }
            if (opcion == 2) {
                pedidoUno.quitarProducto();

            }
            if (opcion == 0 ) {
                break;
            }
        }
        System.out.println("HASTA LA PRÓXIMA");


    }
}
