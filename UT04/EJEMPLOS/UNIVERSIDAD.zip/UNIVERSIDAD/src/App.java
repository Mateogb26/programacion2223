import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        
        var listaMatriculas = new ArrayList<Matriculas>();
        var listaOpciones = new ArrayList<String>();
        listaOpciones.add("1: MODIFICAR UNA NOTA");

        var pepeuno = "pepe";
        var juan = pepeuno;
        juan = "juan";
        System.out.println(pepeuno + juan);

        for (int i=1; i<=25 ; i++) {
            Matriculas miMatricula = new Matriculas(i, "Programación", 1);
            listaMatriculas.add(miMatricula);
        }

        var nuevoAlumno = new Matriculas();
        System.out.println(nuevoAlumno);
        nuevoAlumno = listaMatriculas.get(23);
        System.out.println(nuevoAlumno);
        nuevoAlumno.setNotaMateria(11);
        //System.out.println(listaMatriculas.toString());

        for (Matriculas estaMatricula : listaMatriculas) {
            System.out.println(estaMatricula);
        }
        
        System.out.print("Introduce id alumno:");
        Scanner sc = new Scanner(System.in);
        Integer numLeido = sc.nextInt();
        System.out.println("");
        System.out.print("Introduce nota:");
        Integer notaLeida = sc.nextInt();

        for (Matriculas estaMatricula : listaMatriculas) {
            if (estaMatricula.getAlumnoId() == numLeido) {
                estaMatricula.setNotaMateria(notaLeida);
            }
        }


        for (Matriculas estaMatricula : listaMatriculas) {
            System.out.println(estaMatricula.toString());
        }

        

        //System.out.println(listaMatriculas.toString());
        
    }
}
