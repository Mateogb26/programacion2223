package figuras;

import interfaces.iFigura2D;

public class Cuadrado implements iFigura2D{

    /**
     * Guarda el valor del lado
     */
    private double lado;

    /**
     * Calcula el perímetro usando la fórmula
     * @return el perimetro del cuadrado
     */
    @Override    
    public double perimetro() {        
        return 4*lado;
        
    }

    /**
     * Calula el área del cuadrado
     * @return el valor del área
     */
    @Override
    public double area() {
        return lado*lado;
        
    }

    /**
     * Escalamos el tamaño de la figura
     * @param escala la escala a la que vamos a modificar la figura
     */
    @Override
    public void escalar(double escala) {
        if (escala <=0 ) {
            System.out.println("Valor no válido");
        }
        else {
            lado = lado*escala;
        }
        
    }

    /**
     * Imprimimos información del cuadrado
     */
    @Override
    public void imprimir() {
        System.out.println("Cuadrado -> lado: " + lado);
        
    }

    /**
     * Devuelve el valor del atributo lado
     * @return el lado del cuadrado
     */
    public double getLado() {
        return lado;
    }

    /**
     * Modifica el valor del atributo lado
     * 
     * @param lado el nuevo valor del lado
     */
    public void setLado(double lado) {
        this.lado = lado;
    }
    
}
