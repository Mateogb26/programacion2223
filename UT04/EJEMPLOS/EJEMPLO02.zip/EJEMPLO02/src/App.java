public class App {
    public static void main(String[] args) throws Exception {        

        Pedidos pedidoUno = new Pedidos(1);
        Pedidos pedidoDos = new Pedidos(pedidoUno.idPedido + 1);

        
        pedidoUno.agregarProducto("1 kg de Manzanas");
        pedidoUno.agregarProducto("1 kg de Azúcar");
        pedidoUno.verListaProductos();


    }
}
