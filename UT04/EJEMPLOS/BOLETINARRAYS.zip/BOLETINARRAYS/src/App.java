import java.util.Arrays;
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        int [] arrayEjercicio = new int[boletinArrays.TAMANYO];
        System.out.println("Introduce " + boletinArrays.TAMANYO + " números:");
        for (int i=0; i<boletinArrays.TAMANYO ; i++) {
            arrayEjercicio[i] = sc.nextInt();
        }
        boletinArrays miBoletin = new boletinArrays(arrayEjercicio);
        System.out.println("El array introducido es " 
            + miBoletin.muestraArray());

        int opcion;
        do {
            System.out.println("******************************");
            System.out.println("*     METODOS DE ARRAYS      *");
            System.out.println("*    JOAQUIN RIOS VELASCO    *");
            System.out.println("******************************");
            System.out.println("ESCRIBE TU OPCIÓN:"); 
            System.out.println("1: Desplazar el ARRAY");
            System.out.println("2: Obtener el mayor valor del ARRAY");
            System.out.println("3: Obtener el menor valor del ARRAY");
            System.out.println("4: Modificar un valor del ARRAY");
            System.out.println("5: Obtener la media de los valores del ARRAY");
            System.out.println("0: SALIR");
            opcion = sc.nextInt();
            switch  (opcion) {
                case 1:
                System.out.println("has elegido 1");

                break;
                case 2:
                System.out.println("has elegido 2");
                break;
                case 3:

                break;
                case 4:
                System.out.println("Introduce posicion");
                int posicion = sc.nextInt();   
                System.out.println("Introduce nuevo valor");
                int valor = sc.nextInt(); 
                boolean resultado = miBoletin.insertaValor(posicion, valor);
                if (resultado) {
                    System.out.println("numero modificado correctamente");
                }  
                else {
                    System.out.println("el valor no se ha modificado");
                }
                System.out.println("Valores->" + miBoletin.muestraArray());
                break;
                case 5:
                System.out.println("la media es " + miBoletin.obtenerMedia());
                break;
                default:
                break;
            }
            
        } while (opcion!=0);
        

        
    }
}
