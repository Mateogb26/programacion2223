import java.util.Arrays;
import java.util.Scanner;

public class boletinArrays {
    
    public int[] ejercicioUno(int numeros[]) {
        
        int numeroActual = numeros[numeros.length-1];
        for (int i=numeros.length-1; i>0; i--) {                         
            numeros[i] = numeros[i-1];                
        }
        numeros[0] = numeroActual;
        return numeros;
        
    }



}