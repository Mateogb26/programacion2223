import java.util.Arrays;
import java.util.Scanner;

public class boletinArrays {

    //variable estatica para definir el tamaño del array
    public static int TAMANYO=10;
    // Guardo el array con el que voy a trabajar
    private int[] miArray = new int[TAMANYO];

    //El constructor 
    public boletinArrays (int[] pepe) {
        miArray = pepe;
    }
    
    public int[] rotarArray(int numeros[]) {
        
        int numeroActual = numeros[numeros.length-1];
        for (int i=numeros.length-1; i>0; i--) {                         
            numeros[i] = numeros[i-1];                
        }
        numeros[0] = numeroActual;
        return numeros;
        
    }

    public int obtenerMenor() {
        int menor = miArray[0];
        for (int i : miArray) {
            if (i<menor) {
                menor = i;
            }
        }
        return menor;
    }

    public int obtenerMayor() {
        int mayor = miArray[0];
        for (int i : miArray) {
            if (i>mayor) {
                mayor = i;
            }
        }
        return mayor;
    }

    public double obtenerMedia() {
        double media = 0, suma = 0;
        for (int i : miArray) {
            suma += i;
        }
        media = suma / TAMANYO;
        return media;
    }

    public boolean insertaValor(int posicion, int valor) {
        if (posicion<0 || posicion>(TAMANYO-1)) {
            return false;
        }
        else {
            miArray[posicion] = valor;
            return true;
        }
    }

    public String muestraArray() {
       return Arrays.toString(miArray);
    }

}