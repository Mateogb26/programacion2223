public class Dalmata extends Perro{
    
    private String numeroManchas;

    public void entrenar () {
        System.out.println("entrenando");
    }

    @Override
    public void alimentarse() {
        System.out.println("Dalmata Comiendo");

    }

}
