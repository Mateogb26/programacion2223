public class Animal {

    private String especieAnimal;
    
    public void alimentarse () {
        System.out.println("Alimentando animal");

    }

    public void respirar() {

    }

    public void reproducirse() {

    }

    public String getEspecieAnimal() {
        return especieAnimal;
    }

    public void setEspecieAnimal(String especieAnimal) {
        this.especieAnimal = especieAnimal;
    }

}
