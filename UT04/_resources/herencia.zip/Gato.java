public class Gato extends Animal{
    
    private String raza;

    public void maullar() {
        System.out.println("Maullar");
    }

}
