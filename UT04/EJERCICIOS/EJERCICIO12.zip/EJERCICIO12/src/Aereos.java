public class Aereos extends Vehiculos{
    private final int numAsientos;

    public int getNumAsientos() {
        return numAsientos;
    }

    public Aereos(String matricula, String modelo, int numAsientos) {
        super(matricula, modelo);
        this.numAsientos = numAsientos;
    }

    
}
