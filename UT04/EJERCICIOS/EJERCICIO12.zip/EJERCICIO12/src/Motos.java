public class Motos extends Terrestres{
    private int cilindrada;

    public int getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(int cilindrada) {
        this.cilindrada = cilindrada;
    }

    public Motos(String matricula, String modelo, int numRuedas) {
        super(matricula, modelo, numRuedas);
    }

    
}
