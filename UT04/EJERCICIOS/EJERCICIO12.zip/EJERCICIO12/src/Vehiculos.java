public class Vehiculos {
    private final String matricula;
    private final String modelo;


    
    public Vehiculos(String matricula, String modelo) {
        this.matricula = matricula;
        this.modelo = modelo;
    }


    public String getMatricula() {
        return matricula;
    }
    public String getModelo() {
        return modelo;
    }

    @Override
    public String toString() {
        return "{" + "matricula=" + matricula + 
        ", modelo=" + modelo ;        
    }

    
}
