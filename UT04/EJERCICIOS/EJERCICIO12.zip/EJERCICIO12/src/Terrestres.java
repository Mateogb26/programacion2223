public class Terrestres extends Vehiculos{

    private final int numRuedas;

    public Terrestres(String matricula, String modelo, int numRuedas) {
        super(matricula, modelo);       
        this.numRuedas = numRuedas;
    }

    public int getNumRuedas() {
        return numRuedas;
    }
    
}
