public class Coche extends Terrestres{
    private boolean tieneGPS;

    public Coche(String matricula, String modelo, int numRuedas) {
        super(matricula, modelo, numRuedas);
    }

    public boolean isTieneGPS() {
        return tieneGPS;
    }

    public void setTieneGPS(boolean tieneGPS) {
        this.tieneGPS = tieneGPS;
    }

    
    
}
